function Edit_Validation(){
var name=document.EditMenu_Form.title.value;
var price=document.EditMenu_Form.price.value;
var dateoflaunch=document.EditMenu_Form.dateofLaunch.value;
var category=document.EditMenu_Form.category.value

if(name == null || name == ""){
alert("title is required");
return false;
}

if(!(name.length>2 && name.length<65)){
alert("title should have between 2 to 65 characters");
return false;
}

if(price == null || price == ""){
alert("price is required");
return false;
}
if((isNaN(price))){
alert("Price has to be a number");
return false;

}
if(dateoflaunch == null || dateoflaunch ==""){
alert("dateoflaunch is required");
return false;
}
var pattern=/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/;
if(!dateoflaunch.match(pattern)){
alert("Date of Launch must be in DD/MM/YYYY pattern");
return false;
}
if(category == "" || category == null){
alert("Select one category");
return false;
}
}

function check_radio(){
if(document.getElementById("check_yes").checked==true) {
alert("Yes active");
}
if(document.getElementById("check_no").checked==true){
alert("Not Active");
}
}


function checkbox_delivery(){
if(document.getElementById("check_delivery").checked==true){
alert("Free Delivery available");
}
else{
alert("Free Delivery not available");
}

}