﻿using System;
using System.Collections.Generic;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;

namespace Com.Cognizant.Truyum.Test
{
    class MenuItemDaoCollectionTest
    {
        static void Main(string[] args)
        {
            TestGetMenuItemListAdmin();
            TestGetMenuItemListCustomer();
            TestModifiedMenuItem();
            TestAddcartItem();
            TestRemoveCartItem();
    
            

        }
        public static void TestGetMenuItemListAdmin()
           
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            List<MenuItem> menuList = menuItemDaoCollection.GetMenuItemListAdmin();
            Console.WriteLine("Menu display for admin");
            Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}{6}","Id","Name","Price","Active","Date Of Launch","Category","Free Delivery");

            foreach(MenuItem menu in menuList)
            {
                Console.WriteLine(menu);
            }
            
        }
        public static void TestGetMenuItemListCustomer()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            List<MenuItem> menuList = menuItemDaoCollection.GetMenuItemListCustomer();
            Console.WriteLine("Menu display for customer");
            Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}{6}", "Id", "Name", "Price", "Active", "Date Of Launch", "Category", "Free Delivery");

            foreach (MenuItem menu in menuList)
            {
                Console.WriteLine(menu);
            }
        }
        public static void TestModifiedMenuItem()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            MenuItem modifiedmenu = new MenuItem(1002, "Burger", 300.00f, true, DateUtil.ConvertToShortDate("20/12/2022"), "Starters", true);
            menuItemDaoCollection.ModifyMenuItem(modifiedmenu);
            TestGetMenuItem();
        }
        public static void TestGetMenuItem()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            MenuItem menuItem = menuItemDaoCollection.GetMenuItem(1002);
            if(menuItem!=null)
            {
                Console.WriteLine("\nUpdated Menu");
                Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-18}{5,-10}{6}", "Id", "Name", "Price", "Active", "Date Of Launch", "Category", "Free Delivery");
                Console.WriteLine(menuItem);
            }
            else
            {
                Console.WriteLine("\nNo menu found to modify");
            }
        }

        public static void TestAddcartItem()
        {
            Console.WriteLine("\nAdd new item to cart");
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.AddCartItem(1, 1001);
            try
            {
                TestGetAllCartItem();
            }
            catch(CartEmptyException e)
            {
                Console.WriteLine(e);
            }
            /*cartDao.AddCartItem(2, 1002);
          cartDao.AddCartItem(1, 1005);*/
        }
        public static void TestGetAllCartItem()
        {
            CartDaoCollection cartDao = new CartDaoCollection();
            Cart cart = cartDao.GetAllCartItems(1);
            Console.WriteLine("\nName       FreeDelivery      Price");
            for(int i=0;i<cart.MenuItemList.Count;i++)
            {
                Console.WriteLine(cart.MenuItemList[i].Name+"     "+cart.MenuItemList[i].FreeDelivery+"             "+cart.MenuItemList[i].Price+ "\n Total:  "+cart.Total);
            }
           
        }
       public  static void TestRemoveCartItem()
        {

            Console.WriteLine("\nRemove data from cart");
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.RemoveCartItem(1, 1001);
            try
            {
                TestGetAllCartItem();
            }
            catch (CartEmptyException e)
            {
                Console.WriteLine(e);
            }

        }
    }
}
